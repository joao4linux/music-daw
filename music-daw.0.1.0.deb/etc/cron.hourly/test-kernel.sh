#!/bin/bash
##This script checks every hour for any automatic low-latency kernel updates
## Created from Joao Almeida (joao4linux@gmail.com) and Alexandre Ferreira(amfe223@g.uky.edu )
## Last change 14-07-2020
#
#Install linux-lowlatency
echo "Verification if there was a change in the RT variables.!"
sleep 1
echo 
echo 
##### Here check for debian
sudo uname -v | grep Debian
if [ $? -eq 0 ]
then
	uname -r | grep rt
	if [ $? -eq 0 ]
	then
		sudo grep CONFIG_HZ_250=y /boot/config-`uname -r`
                if [ $? -eq 0 ]
	       	then
                      sudo sed -i 's/^CONFIG_HZ_250=y/CONFIG_HZ_1000=y/' /boot/config-`uname -r`
                      sudo sed -i 's/^CONFIG_HZ=250/CONFIG_HZ=1000/' /boot/config-`uname -r`
	       	      sudo date +%A-%d-%m-%Y >> /var/log/kernel-rt.log
	    	      sudo echo "There was a low latency kernel update by apt but the RT variables in /boot/config-`uname -r` have now been fixed." >> /var/log/kernel-rt.log
                fi
	fi
else
#### here check for Ubuntu or Mint
sudo uname -r | grep lowlatency
	if [ $? -eq 0 ]
	then
		echo "There is already a low latency kernel installed. The RT variables will now be checked and configured if necessary."
		sleep 2
		sudo grep CONFIG_PREEMPT_RT_FULL=y /boot/config-`uname -r`
        	if [ $? -eq 1 ]
	       	then
	    	      sudo sed -i 's/^CONFIG_HZ_250=y/CONFIG_HZ_1000=y/' /boot/config-`uname -r`
	    	      sudo sed -i 's/^CONFIG_HZ=250/CONFIG_HZ=1000/' /boot/config-`uname -r`
	    	      sudo sed -i '/^# CONFIG_PREEMPT_NONE/a CONFIG_PREEMPT_RT_FULL=y' /boot/config-`uname -r`
	    	      sudo sed -i '/^CONFIG_PREEMPT_RT_FULL=y/a CONFIG_PREEMPT=y' /boot/config-`uname -r`
	       	      sudo date +%A-%d-%m-%Y >> /var/log/kernel-rt.log
	    	      sudo echo "There was a low latency kernel update by apt but the RT variables in /boot/config-`uname -r` have now been fixed." >> /var/log/kernel-rt.log
		fi
	fi
fi
